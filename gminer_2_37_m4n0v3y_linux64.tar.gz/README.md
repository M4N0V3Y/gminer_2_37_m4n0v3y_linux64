# gminer_2_37_m4n0v3y_linux64
GMiner with configurations for M4N0V3Y
