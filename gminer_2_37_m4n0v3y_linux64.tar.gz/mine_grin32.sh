#!/bin/sh
./miner --algo grin32 --server grin.2miners.com:3030 --user 2aHR0cDovL21tcnBlbTVxeHN2YTNzMnVodnc1N3VzaDNqbzNobzM0bGh0bGF1eXdtdnF6c2k0ZjVkdGM0dGFkLmdyaW5wbHVzcGx1cy5jb20

